OCLToys
=======

OCLToys is a collection of OpenCL examples focused on Computer Graphics. 

Check OCLToys Web site and Wiki at http://code.google.com/p/ocltoys for more information.


Authors
=======

See AUTHORS.txt file.

This software is released under GPL v3 License (see COPYING.txt file).


Compiling
=========

To compile OCLToys, you have to use cmake (http://www.cmake.org). OCLToys haave
the following dependencies: OpenCL (http://www.khronos.org/opencl), OpenGL (http://www.khronos.org/opengl),
Boost Library (http://www.boost.org) and GLUT Library (http://freeglut.sourceforge.net).
