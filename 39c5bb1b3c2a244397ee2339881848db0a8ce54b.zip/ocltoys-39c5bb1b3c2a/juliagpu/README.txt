JuliaGPU
========

JuliaGPU is a small and simple demo written in OpenCL in order to test the
performance of this new standard. It is based on Keenan Crane's qjulia
available at http://www.cs.caltech.edu/~keenan/project_qjulia.html.
The idea of Ambient Occlusion comes from Tom Beddard's
http://www.subblue.com/blog/2009/9/20/quaternion_julia.

This demo works with OpenCL 1.0.


Key bindings
============

Check the on screen help.


History
=======

V1.0 - First release
